#' @title Light Use efficiency model
#' @description >full description>
#' @param fpar fpar raster
#' @param par par raster
#' @param tmin tmin raster
#' @param min minimum value of tmin
#' @param max maximum value of tmin
#' @param LUE_optimal optical lue value with respective of crop type
#' @seealso \code{\link[lue]}{head}]
LUE_BIOMASS<-function(fpar=x,par=y,tmin=t,tmin_min=min,tmin_max=max,LUE_optimal=lue) {
  par<-sum(par)
  par <- par/1000000 # convert PAR from J*m^-2 to MJ*m^-2
  par <- projectRaster(y, fpar, method = "bilinear", verbose = TRUE)
  apar <- par * fpar
  tmin<-mean(tmin)
  tmin <- projectRaster(t, fpar, method = "bilinear", verbose = TRUE)
  #t<- as.vector(t)
  tmin <- tmin - 273.15
  tmin<-getValues(t)
  for (j in 1:length(t)){
    if (tmin[j] <= min){
      tmin[j] <- 0
    } else if (tmin[j] >= max){
      tmin[j] <- 1
    } else {
      tmin[j] <- (tmin[j] - min)* ((1/(max-min)))
    }
  }
  lue_act <- tmin * lue
  biomass<-apar*lue_act
  plot(biomass)
}

