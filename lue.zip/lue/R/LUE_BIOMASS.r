#' @title Light Use efficiency model to estimate biomass
#' @description Contains LUE_BIOMASS function to estimate aboveground biomass firstly by calculating the apar and then the minimum temperature and actual values of light use efficiency are further used to calculate the biomass of a crop.
#' @param fpar_raster fraction of photosynthetically active radiation (fpar) per day raster in .tif format
#' @param par clear sky surface photosynthetically active radiation (par) per day raster with .ncd file format.
#' @param tmin Minimum temperature at 2 metres since previous post-processing per day raster with .ncd file format.
#' @param tmin_min minimum value of tmin used for the threshold
#' @param tmin_max maximum value of tmin used for the threshold
#' @param LUE_optimal optical lue value with respect to crop type for example wheat crop LUE_optimal is 3.0 (Djumaniyazova et al., 2010)
#' @seealso \code{\link[lue]}{head}]
#' @import fpar,par and tmin rasters
#' @references Djumaniyazova Y, Sommer R, Ibragimov N, Ruzimov J, Lamers J & Vlek P (2010) Simulating water use and N response of winter wheat in the irrigated floodplains of Northwest Uzbekistan. Field Crops Research 116, 239-251.
#' @references Shi Z, Ruecker G R,Mueller M, Conrad C, Ibragimov N, Lamers J P A, Martius C, Strunz G, Dech S & Vlek P L G (2007) Modeling of Cotton Yields in the Amu Darya River Floodplains of Uzbekistan Integrating Multitemporal Remote Sensing and Minimum Field Data. Agronomy Journal 99, 1317-1326
# #' @examples ## Not run:
# #'   library(lue)
#  #'   fpar<- load("~/R/lue/data/fpar.rda")
# #'   par<- load("~/R/lue/data/par.rda")
# #'   tmin<- load("~/R/lue/data/tmin.rda")
# #'   LUE_BIOMASS(fpar,par,tmin,-2,12,3)
## End(Not run)
#' @return Biomass raster
LUE_BIOMASS<-function(fpar_raster,par,tmin,tmin_min,tmin_max,LUE_optimal) {
      #Summing the PAR for a day
      par<-sum(par)
      # converting PAR from J*m^-2 to MJ*m^-2
      par <- par/1000000 # convert PAR from J*m^-2 to MJ*m^-2
      # converting PAR to the same extent as fpar raster
      par <- projectRaster(par, fpar_raster, method = "bilinear", verbose = TRUE)
      options(warn=-1)
      # calculating apar by multipying par with fpar
      apar <- par * fpar_raster
      # including tmin with a mean value in a day
      tmin<-mean(tmin)
      tmin <- projectRaster(tmin, fpar_raster, method = "bilinear", verbose = TRUE)
      options(warn=-1)
      # making it in degree celsius
      tmin <- tmin - 273.15
      tmin<-getValues(tmin)
      # applying the criteria with diffrent thresholds of tmin for every crop
        for (j in 1:length(tmin)){
          if (tmin[j] <= tmin_min){
            tmin[j] <- 0
                                  }
          else if (tmin[j] >= tmin_max){
            tmin[j] <- 1
                                        }
          else {
          tmin[j] <- (tmin[j] - tmin_min)* ((1/(tmin_max-tmin_min)))
                }
                                }
lue_act <- tmin * LUE_optimal
biomass<-apar*lue_act
return(biomass)
                                                                            }



